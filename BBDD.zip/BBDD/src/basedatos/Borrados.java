package basedatos;

public class Borrados {

}
