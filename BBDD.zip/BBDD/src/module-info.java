/**
 * 
 */
/**
 * 
 */
module BBDD {
	requires java.sql;
}